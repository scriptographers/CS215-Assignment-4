clc;
clear;
close all;

% Find A from Covariance matrix C where C=A*A'
mu = [1; 2];
cov = [1.6250 -1.9486; -1.9486 3.8750];
[Q, D] = eig(cov);
A = Q*sqrt(D); % square root of a diagonal matrix is square root of individual elements

% Find norm of mu and frobenius norm of cov
norm_mu = norm(mu);
norm_cov = norm(cov);

% Initialize empty matrices to store error
mean_err = zeros(100, 5);
cov_err = zeros(100, 5);

for lN=1:5 % Looping over values of log10(N)
    N = 10^lN;
    for iter=1:100 % Repeating 100 times for a given N
        rng(2*iter); % Setting seed to reproduce results
        x = A * randn(2,N) + mu; % values from X
        
        % ML estimate of mean is sum(x)/N
        mean_mle = sum(x,2) / N;
        % ML estimate of covariance matrix is sum((x-mu^)(x-mu^)')/N
        cov_mle = (x-mean_mle)*(x-mean_mle)' / N;
        
        % Error measure of mean and covariance
        mean_err(iter,lN) = norm(mu - mean_mle) / norm_mu; % Where lN = log10(N)
        cov_err(iter,lN) = norm(cov - cov_mle) / norm_cov; % Where lN = log10(N)
    end
    
    figure;
    % Plot data points for seed=100
    scatter(x(1,:), x(2,:), 10/((lN)^(1.2)), "filled");
    
    % Calculating principal mode of variation
    [Q, lambda] = eig(cov_mle);
    if lambda(1, 1) > lambda(2, 2)
        ep = D(1,1)*Q(:, 1);
    else
        ep = D(2,2)*Q(:, 2);
    end
    hold on;
    quiver(mean_mle(1), mean_mle(2), ep(1), ep(2), 'Color', 'red', 'LineStyle', '-', 'LineWidth', 1);
    scatter(mean_mle(1), mean_mle(2), 250, 'r.');
    title(sprintf("N = %i", N));
    saveas(gcf, sprintf("../results/d_%i.jpg", N)); % Save current figure
    hold off;
end

% Box plotting the mean error values for different N
figure;
boxplot(mean_err);
title('Error b/w True mean & ML estimate');
ylabel('Error');
xlabel('log_{10}(N)');
saveas(gcf, "../results/mean_err.jpg"); % Save current figure

% Box plotting the covariance error values for different N
figure;
boxplot(cov_err);
title('Error b/w True covariance & ML estimate');
ylabel('Error');
xlabel('log_{10}(N)');
saveas(gcf, "../results/cov_err.jpg"); % Save current figure

close all;

function ret = norm(x)
    ret = sqrt(sum(x.*x, 'all'));
    % 'all' makes this function useful for calculating 2-norm for vectors
    % and frobenius norm for matrices
end
